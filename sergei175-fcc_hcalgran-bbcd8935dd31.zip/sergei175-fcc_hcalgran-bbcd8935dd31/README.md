# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###


* Paper draft for FCC HCAL granularity studies 
* 1.0
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* Get the paper as:
  git clone https://sergei175@bitbucket.org/sergei175/fcc_hcalgran.git

### Contribution guidelines ###

To compile the paper, type "make". To look at PDF, type "make show"

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact
